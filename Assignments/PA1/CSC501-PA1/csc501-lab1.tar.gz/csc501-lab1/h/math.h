#ifndef math_h
#define math_h

#define RAND_MAX 077777; 
//#define RAND_MAX 032767;
//https://moodle-courses1819.wolfware.ncsu.edu/mod/forumng/discuss.php?d=8975
/*
	extern double pow(double base, int exponent);
	//double pow(double x, int y);
	extern double log(double base);
	extern double expdev(double lambda);
*/

	double pow(double base, int exponent);
       // double pow(double x, int y);
        double log(double base);
       	double expdev(double lambda);
#endif
